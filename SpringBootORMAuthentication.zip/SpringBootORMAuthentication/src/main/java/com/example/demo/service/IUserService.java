package com.example.demo.service;

import com.example.demo.dto.UserRequest;
import com.example.demo.entity.User;

public interface IUserService {
	
	String saveUser(User user);

	boolean checkLoginCredentials(UserRequest userRequest);

}
