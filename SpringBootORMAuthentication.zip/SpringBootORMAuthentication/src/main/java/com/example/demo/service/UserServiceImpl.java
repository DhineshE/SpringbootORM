package com.example.demo.service;

import java.util.Optional;

import com.example.demo.dto.UserRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.demo.entity.User;
import com.example.demo.repo.UserRepository;

@Service
public class UserServiceImpl implements IUserService  {

	@Autowired
	private UserRepository urepo;
	
	@Autowired
	private PasswordEncoder passwordEncoder;

	@Override
	public String saveUser(User user) {
		String password=user.getPassword();
		String encodedPassword=passwordEncoder.encode(password);
		user.setPassword(encodedPassword);
		User savedUser=urepo.save(user);
		String msg="User With ID :"+savedUser.getUid()+" Registered Successfully";
		return msg;
	}
	
	public boolean checkLoginCredentials(UserRequest userRequest){
		Optional<User> userOptional= urepo.findByUsername(userRequest.getUsername());
		String encodedPassword = passwordEncoder.encode(userRequest.getPassword());
		if(userOptional.isEmpty()){
			return false;
		}
		else if(userOptional.get().getPassword() == encodedPassword){
			return true;
		}
		else{
			return false;
		}
	}
}
